/**
 * <p>This package contains a class used to handle expressions with an array of operands.</p>
 */
package net.sf.saxon.expr.oper;
