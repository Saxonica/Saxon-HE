/**
 * <p>This package contains classes used to implement XSLT 3.0 accumulators, in particular,
 * accumulators for non-streamed documents.</p>
 */
package net.sf.saxon.expr.accum;
