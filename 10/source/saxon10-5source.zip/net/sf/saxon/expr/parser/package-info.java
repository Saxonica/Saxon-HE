/**
 * <p>This package contains classes associated with parsing and general static analysis of XPath expressions.</p>
 */
package net.sf.saxon.expr.parser;
