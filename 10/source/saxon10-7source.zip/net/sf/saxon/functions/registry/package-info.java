/**
 * <p>This package contains libraries of function signatures for the standard functions available in various Saxon-HE environments.</p>
 */
package net.sf.saxon.functions.registry;
