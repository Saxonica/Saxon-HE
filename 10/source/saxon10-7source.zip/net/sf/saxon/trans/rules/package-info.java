/**
 * <p>This package provides classes to implement matching of patterns for selection
 * of template rules within a mode.</p>
 */
package net.sf.saxon.trans.rules;
