/**
 * <p>This package contains classes concerned with evaluation of expressions in XPath 1.0 compatibility mode.</p>
 */
package net.sf.saxon.expr.compat;
