/**
 * <p>This package contains subpackages containing the code for different tree models. It also contains
 * the class {@link net.sf.saxon.tree.NamespaceNode} which is used by several tree models.</p>
 */
package net.sf.saxon.tree;
