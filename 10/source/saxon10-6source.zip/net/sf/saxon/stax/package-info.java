/**
 * <p>This package contains classes used to connect to StAX (pull-parser) events for input and output.</p>
 */
package net.sf.saxon.stax;
