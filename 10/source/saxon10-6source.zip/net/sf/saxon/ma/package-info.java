/**
 * <p>This package contains classes associated with the implementation of maps, arrays, and JSON
 * for XSLT 3.0 and XPath 3.1.</p>
 * <p align="center"><i>Michael H. Kay<br/>
 * Saxonica Limited<br/>
 * June 2015</i></p>
 */
package net.sf.saxon.ma;
