/**
 * <p>This package implements support for JSON: it includes classes that implement the XPath 3.1 functions
 * for JSON, and underlying support code for parsing and serializating JSON.</p>
 */
package net.sf.saxon.ma.json;
