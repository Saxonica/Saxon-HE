////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// Copyright (c) 2018-2026 Saxonica Limited
// This Source Code Form is subject to the terms of the Mozilla Public License, v. 2.0.
// If a copy of the MPL was not distributed with this file, You can obtain one at http://mozilla.org/MPL/2.0/.
// This Source Code Form is "Incompatible With Secondary Licenses", as defined by the Mozilla Public License, v. 2.0.
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

package net.sf.saxon.expr.flwor;

import net.sf.saxon.event.Outputter;
import net.sf.saxon.expr.XPathContext;
import net.sf.saxon.trans.XPathException;
import net.sf.saxon.value.AtomicValue;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

/**
 * Represents the tuple stream delivered by an "group by" clause. This groups the tuple stream supplied
 * as its input, and outputs a new set of tuples one per group of the input tuples. No groups are output
 * until all the groups have been read.
 */
public class GroupByClausePush extends TuplePush {

    private final TuplePush destination;
    private final GroupByClause groupByClause;
    private final HashMap<Object, List<GroupByClause.ObjectToBeGrouped>> map = new HashMap<>();
    private final XPathContext context;
    
    public GroupByClausePush(Outputter outputter, TuplePush destination, GroupByClause groupBy, XPathContext context) {
        super(outputter);
        this.destination = destination;
        this.groupByClause = groupBy;
        this.context = context;
    }

    /**
     * Move on to the next tuple. Before returning, this method must set all the variables corresponding
     * to the "returned" tuple in the local stack frame associated with the context object
     *
     * @param context the dynamic evaluation context
     */
    @Override
    public void processTuple(XPathContext context) throws XPathException {

        // Allocate the incoming tuple to a group

        TupleExpression groupingTupleExpr = groupByClause.getGroupingTupleExpression();
        TupleExpression retainedTupleExpr = groupByClause.getRetainedTupleExpression();


        AtomicValue[] groupingValues = groupingTupleExpr.evaluateItemAllAtomic(context).getValues();
        GroupByClause.ObjectToBeGrouped otbg = new GroupByClause.ObjectToBeGrouped(
                new FlworTuple<AtomicValue>(groupingValues),
                retainedTupleExpr.evaluateItem(context)
        );
        GroupByClause.TupleComparisonKey key = groupByClause.getComparisonKey(otbg.groupingValues(), context);
        List<GroupByClause.ObjectToBeGrouped> group = map.get(key);
        addToGroup(key, otbg, group, map);
    }

    protected static void addToGroup(
            Object key,
            GroupByClause.ObjectToBeGrouped objectToBeGrouped,
            List<GroupByClause.ObjectToBeGrouped> group,
            HashMap<Object, List<GroupByClause.ObjectToBeGrouped>> map) {
        if (group != null) {
            group.add(objectToBeGrouped);
            map.put(key, group);
        } else {
            List<GroupByClause.ObjectToBeGrouped> list = new ArrayList<>();
            list.add(objectToBeGrouped);
            map.put(key, list);
        }
    }

//    protected static void checkGroupingValues(Sequence[] groupingValues) throws XPathException {
//        try {
//            for (int i = 0; i < groupingValues.length; i++) {
//                Sequence v = groupingValues[i];
//                if (!(v instanceof EmptySequence || v instanceof AtomicValue)) {
//                    v = SequenceTool.toGroundedValue(Atomizer.getAtomizingIterator(v.iterate(), false));
//                    if (SequenceTool.getLength(v) > 1) {
//                        throw new XPathException("Grouping key value cannot be a sequence of more than one item", "XPTY0004");
//                    }
//                    groupingValues[i] = v;
//                }
//            }
//        } catch (UncheckedXPathException e) {
//            throw e.getXPathException();
//        }
//    }


    /**
     * Close the tuple stream, indicating that although not all tuples have been read,
     * no further tuples are required and resources can be released
     */

    @Override
    public void close() throws XPathException {

        for (List<GroupByClause.ObjectToBeGrouped> group : map.values()) {
            groupByClause.processGroup(group, context);
            destination.processTuple(context);
        }

        destination.close();
    }


}

// Copyright (c) 2011-2026 Saxonica Limited
