/// /////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// Copyright (c) 2026 Saxonica Limited
// This Source Code Form is subject to the terms of the Mozilla Public License, v. 2.0.
// If a copy of the MPL was not distributed with this file, You can obtain one at http://mozilla.org/MPL/2.0/.
// This Source Code Form is "Incompatible With Secondary Licenses", as defined by the Mozilla Public License, v. 2.0.
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

package net.sf.saxon.event;

/**
 * Interface implemented by a class (typically a {@link Receiver}
 * that can be aborted: supports {@link PipelineConfiguration#abort(Receiver)}
 */
public interface Abortable {

    /**
     * Abort the operation of the class. Typically used to prevent a Receiver
     * processing further events.
     */
    void abort();
}
