/// /////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// Copyright (c) 2026 Saxonica Limited
// This Source Code Form is subject to the terms of the Mozilla Public License, v. 2.0.
// If a copy of the MPL was not distributed with this file, You can obtain one at http://mozilla.org/MPL/2.0/.
// This Source Code Form is "Incompatible With Secondary Licenses", as defined by the Mozilla Public License, v. 2.0.
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

package net.sf.saxon.event;

import net.sf.saxon.serialize.ExpandedStreamResult;

/**
 * A ProxyReceiver that passes all events through unchanged, but which holds information about
 * the final destination of a serialization pipeline.
 */

public class ProxyReceiverWithExpandedStreamResult extends ProxyReceiver {

    public ExpandedStreamResult expandedResult;

    /**
     * Create a ProxyReceiverWithExpandedStreamResult that passes everything unchanged to the next receiver,
     * but captures information about the final result destination
     * @param nextReceiver the next receiver in the serialization pipeline
     * @param expandedResult the final destination of the pipeline
     */

    public ProxyReceiverWithExpandedStreamResult(Receiver nextReceiver, ExpandedStreamResult expandedResult) {
        super(nextReceiver);
        this.expandedResult = expandedResult;
    }

    /**
     * Drop an unnecessary {@code ProxyReceiverWithExpandedStreamResult} from the pipeline
     * @param receiver a receiver
     * @return the supplied receiver unless it is a {@code ProxyReceiverWithExpandedStreamResult}, in which
     * case the next receiver in the pipeline
     */

    public static Receiver eliminate(Receiver receiver) {
        if (receiver instanceof ProxyReceiverWithExpandedStreamResult proxy) {
            return proxy.nextReceiver;
        } else {
            return receiver;
        }
    }
}
