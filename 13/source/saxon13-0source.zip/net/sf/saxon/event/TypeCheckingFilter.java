////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// Copyright (c) 2018-2026 Saxonica Limited
// This Source Code Form is subject to the terms of the Mozilla Public License, v. 2.0.
// If a copy of the MPL was not distributed with this file, You can obtain one at http://mozilla.org/MPL/2.0/.
// This Source Code Form is "Incompatible With Secondary Licenses", as defined by the Mozilla Public License, v. 2.0.
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

package net.sf.saxon.event;

import net.sf.saxon.expr.parser.Loc;
import net.sf.saxon.expr.parser.RoleDiagnostic;
import net.sf.saxon.om.*;
import net.sf.saxon.type.gnode.NodeKindType;
import net.sf.saxon.s9api.Location;
import net.sf.saxon.str.EmptyUnicodeString;
import net.sf.saxon.str.UnicodeString;
import net.sf.saxon.trans.XPathException;
import net.sf.saxon.transpile.CSharpReplaceMethod;
import net.sf.saxon.tree.util.Orphan;
import net.sf.saxon.type.*;
import net.sf.saxon.value.Cardinality;

import java.util.HashSet;
import java.util.function.Supplier;

/**
 * A filter on the push pipeline that performs type checking, both of the item type and the
 * cardinality.
 * <p>Note that the TypeCheckingFilter cannot currently check document node tests of the form
 * document-node(element(X,Y)), so it is not invoked in such cases. This isn't a big problem, because most
 * instructions that return document nodes materialize them anyway.</p>
 */

public class TypeCheckingFilter extends ProxyOutputter {

    private ItemType requiredType;
    private int cardinality;
    private RoleDiagnostic roleDiagnostic;
    private Location locator;
    private int count = 0;
    private int level = 0;
    private boolean allowAnyNode = false;
    private final HashSet<Long> checkedElements = new HashSet<>(10);
    // used to avoid repeated checking when a template creates large numbers of elements of the same type
    // The key is a (namecode, typecode) pair, packed into a single long
    private final TypeHierarchy typeHierarchy;

    public TypeCheckingFilter(Outputter next) {
        super(next);
        typeHierarchy = getConfiguration().getTypeHierarchy();

    }

    public void setRequiredType(ItemType type, int cardinality, RoleDiagnostic roleDiagnostic, Location locator) {
        requiredType = type;
        this.cardinality = cardinality;
        this.roleDiagnostic = roleDiagnostic;
        this.locator = locator;
        Affinity aff = typeHierarchy.relationship(requiredType, NodeKindType.ELEMENT);
        allowAnyNode = aff == Affinity.SAME_TYPE || aff == Affinity.SUBSUMES;
    }

    /**
     * Notify a namespace binding.
     */
    @Override
    public void namespace(String prefix, NamespaceUri namespaceUri, int properties) throws XPathException {
        if (level == 0) {
            if (++count == 2) {
                checkAllowsMany(Loc.NONE);
            }
            Orphan ns = new Orphan(getConfiguration());
            ns.setNodeKind(Type.NAMESPACE);
            ns.setNodeName(new NoNamespaceName(prefix));
            checkItem(ns, Loc.NONE);
        }
        getNextOutputter().namespace(prefix, namespaceUri, properties);
    }

    /**
     * Notify an attribute.
     */
    @Override
    public void attribute(NodeName attName, SimpleType typeCode, String value, Location location, int properties) throws XPathException {
        if (level == 0) {
            if (++count == 2) {
                checkAllowsMany(location);
            }
            Orphan att = new Orphan(getConfiguration());
            att.setNodeKind(Type.ATTRIBUTE);
            att.setNodeName(attName);
            att.setTypeAnnotation(typeCode);
            checkItem(att, location);
        }
        getNextOutputter().attribute(attName, typeCode, value, location, properties);
    }

    /**
     * Character data
     */

    @Override
    public void characters(UnicodeString chars, Location locationId, int properties) throws XPathException {
        if (level == 0) {
            if (++count == 2) {
                checkAllowsMany(locationId);
            }
            Orphan txt = new Orphan(getConfiguration());
            txt.setNodeKind(Type.TEXT);
            txt.setStringValue(chars);
            checkItem(txt, locationId);
        }
        getNextOutputter().characters(chars, locationId, properties);
    }

    /**
     * Output a comment
     */

    @Override
    public void comment(UnicodeString chars, Location locationId, int properties) throws XPathException {
        if (level == 0) {
            if (++count == 2) {
                checkAllowsMany(locationId);
            }
            Orphan comment = new Orphan(getConfiguration());
            comment.setNodeKind(Type.COMMENT);
            checkItem(comment, locationId);
        }
        getNextOutputter().comment(chars, locationId, properties);
    }

    /**
     * Processing Instruction
     */

    @Override
    public void processingInstruction(String target, UnicodeString data, Location locationId, int properties) throws XPathException {
        if (level == 0) {
            if (++count == 2) {
                checkAllowsMany(locationId);
            }
            Orphan pi = new Orphan(getConfiguration());
            pi.setNodeKind(Type.PROCESSING_INSTRUCTION);
            pi.setNodeName(new NoNamespaceName(target));
            checkItem(pi, locationId);
        }
        getNextOutputter().processingInstruction(target, data, locationId, properties);
    }

    /**
     * Start of a document node.
     */

    @Override
    public void startDocument(int properties) throws XPathException {
        if (level == 0) {
            if (++count == 2) {
                checkAllowsMany(Loc.NONE);
            }
            checkItemType(NodeKindType.DOCUMENT,
                          nodeSupplier(Type.DOCUMENT, null, null, EmptyUnicodeString.getInstance()), Loc.NONE);
        }
        level++;
        getNextOutputter().startDocument(properties);
    }

    /**
     * Notify the start of an element
     */

    @Override
    public void startElement(NodeName elemName, SchemaType elemType,
                             Location location, int properties) throws XPathException {
        checkElementStart(elemName, elemType, location);
        getNextOutputter().startElement(elemName, elemType, location, properties);
    }

    /**
     * Notify the start of an element, supplying all attributes and namespaces
     *
     * @param elemName   the name of the element.
     * @param type       the type annotation of the element.
     * @param attributes the attributes of this element
     * @param namespaces the in-scope namespaces of this element: generally this is all the in-scope
     *                   namespaces, without relying on inheriting namespaces from parent elements
     * @param location   an object providing information about the module, line, and column where the node originated
     * @param properties bit-significant properties of the element node. If there are no relevant
     *                   properties, zero is supplied. The definitions of the bits are in class {@link ReceiverOption}
     * @throws XPathException if an error occurs
     */
    @Override
    public void startElement(NodeName elemName, SchemaType type, AttributeMap attributes, NamespaceMap namespaces, Location location, int properties) throws XPathException {
        checkElementStart(elemName, type, location);
        getNextOutputter().startElement(elemName, type, attributes, namespaces, location, properties);
    }

    private void checkElementStart(NodeName elemName, SchemaType elemType, Location location) throws XPathException {
        if (level == 0) {
            if (++count == 2) {
                checkAllowsMany(location);
            }
            if (!allowAnyNode) {
                Orphan node = new Orphan(getConfiguration());
                node.setNodeKind(Type.ELEMENT);
                node.setNodeName(elemName);
                node.setTypeAnnotation(elemType);
                checkItem(node, location);
            }
        }
        level++;
    }

    /**
     * Notify the end of a document node
     */

    @Override
    public void endDocument() throws XPathException {
        level--;
        getNextOutputter().endDocument();
    }

    /**
     * End of element
     */

    @Override
    public void endElement() throws XPathException {
        level--;
        getNextOutputter().endElement();
    }

    /**
     * End of event stream
     */

    @Override
    public void close() throws XPathException {
        finalCheck();
        super.close();
    }

    public void finalCheck() throws XPathException {
        if (count == 0 && !Cardinality.allowsZero(cardinality)) {
            String errorCode = roleDiagnostic.getErrorCode();
            XPathException err = new XPathException("An empty sequence is not allowed as the " +
                                                            roleDiagnostic.getMessage())
                    .withErrorCode(errorCode);
            if (!"XPDY0050".equals(errorCode)) {
                err.setIsTypeError(true);
            }
            throw err;
        }
    }

    private Supplier<NodeInfo> nodeSupplier(short nodeKind, NodeName name, SchemaType type, UnicodeString value) {
        return () -> {
            Orphan o = new Orphan(getPipelineConfiguration().getConfiguration());
            o.setNodeKind(nodeKind);
            if (name != null) {
                o.setNodeName(name);
            }
            o.setTypeAnnotation(type);
            o.setStringValue(value);
            return o;
        };
    }

    /**
     * Output an item (atomic value or node) to the sequence
     */

    @Override
    public void append(Item item, Location locationId, int copyNamespaces) throws XPathException {
        if (level == 0) {
            if (++count == 2) {
                checkAllowsMany(locationId);
            }
            checkItem(item, locationId);
        }
        getNextOutputter().append(item, locationId, copyNamespaces);
    }

    /**
     * Output an item (atomic value or node) to the sequence
     */

    @Override
    public void append(Item item) throws XPathException {
        if (level == 0) {
            if (++count == 2) {
                checkAllowsMany(Loc.NONE);
            }
            checkItem(item, Loc.NONE);
        }
        getNextOutputter().append(item);
    }

    /**
     * Ask whether this Receiver (or the downstream pipeline) makes any use of the type annotations
     * supplied on element and attribute events
     *
     * @return true if the Receiver makes any use of this information. If false, the caller
     *         may supply untyped nodes instead of supplying the type annotation
     */

    @Override
    public boolean usesTypeAnnotations() {
        return true;
    }

    @CSharpReplaceMethod(code="    private void checkItemType<T>(Saxon.Hej.type.ItemType type, Saxon.Ejava.util.function.Supplier<T> itemSupplier, Saxon.Hej.s9api.Location locationId) where T : Saxon.Hej.om.Item {"
            + "        if (!(typeHierarchy.isSubType(type, requiredType))) {"
            + "            throwTypeError(type, itemSupplier(), locationId);"
            + "        }"
            + "    }")
    private void checkItemType(ItemType type, Supplier<? extends Item> itemSupplier, Location locationId) throws XPathException {
        if (!typeHierarchy.isSubType(type, requiredType)) {
            throwTypeError(type, itemSupplier.get(), locationId);
        }
    }

    private void checkItemType(ItemType type, Location locationId) throws XPathException {
        if (!typeHierarchy.isSubType(type, requiredType)) {
            throwTypeError(type, null, locationId);
        }
    }

    private void checkItem(Item item, Location locationId) throws XPathException {
        if (!requiredType.matches(item)) {
            throwTypeError(requiredType, item, locationId);
        }
    }


    private void throwTypeError(ItemType suppliedType, Item item, Location locationId) throws XPathException {
        String message;
        if (item == null) {
            message = roleDiagnostic.composeErrorMessage(requiredType, suppliedType);
        } else {
            message = roleDiagnostic.composeErrorMessage(requiredType, item, typeHierarchy);
        }
        String errorCode = roleDiagnostic.getErrorCode();
        throw new XPathException(message, errorCode)
                .asTypeErrorIf(!"XPDY0050".equals(errorCode))
                .withLocation(locationId == null ? locator : locationId.saveLocation());
    }

    private void checkAllowsMany(Location locationId) throws XPathException {
        if (!Cardinality.allowsMany(cardinality)) {
            throw new XPathException("A sequence of more than one item is not allowed as the " +
                                                            roleDiagnostic.getMessage())
                    .withErrorCode(roleDiagnostic.getErrorCode())
                    .asTypeErrorIf(!"XPDY0050".equals(roleDiagnostic.getErrorCode()))
                    .withLocation(locationId == null || locationId == Loc.NONE ? locator : locationId);
        }
    }


}

