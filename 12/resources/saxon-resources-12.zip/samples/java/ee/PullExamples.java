////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// Copyright (c) 2018-2023 Saxonica Limited
// This Source Code Form is subject to the terms of the Mozilla Public License, v. 2.0.
// If a copy of the MPL was not distributed with this file, You can obtain one at http://mozilla.org/MPL/2.0/.
// This Source Code Form is "Incompatible With Secondary Licenses", as defined by the Mozilla Public License, v. 2.0.
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

package ee;

import com.saxonica.config.EnterpriseConfiguration;
import com.saxonica.xqj.pull.PullFromIterator;
import com.saxonica.xqj.pull.PullNamespaceReducer;
import com.saxonica.xqj.pull.PullTracer;
import com.saxonica.xqj.pull.TreeWalker;
import net.sf.saxon.Configuration;
import net.sf.saxon.TransformerFactoryImpl;
import net.sf.saxon.event.PipelineConfiguration;
import net.sf.saxon.event.Receiver;
import net.sf.saxon.event.Sink;
import net.sf.saxon.lib.ParseOptions;
import net.sf.saxon.lib.SerializerFactory;
import net.sf.saxon.lib.Validation;
import net.sf.saxon.om.*;
import net.sf.saxon.pull.*;
import net.sf.saxon.query.DynamicQueryContext;
import net.sf.saxon.query.StaticQueryContext;
import net.sf.saxon.query.XQueryExpression;
import net.sf.saxon.serialize.SerializationProperties;
import net.sf.saxon.trans.XPathException;
import net.sf.saxon.tree.linked.LinkedTreeBuilder;
import net.sf.saxon.tree.tiny.TinyBuilder;

import javax.xml.transform.*;
import javax.xml.transform.stream.StreamResult;
import javax.xml.transform.stream.StreamSource;
import java.io.*;
import java.util.Properties;

import static net.sf.saxon.pull.PullEvent.START_ELEMENT;

/**
 * This class contains some examples of how to use the Pull interfaces in Saxon. Note that these
 * are relatively low-level interfaces provided primarily for integrating Saxon with other libraries
 * that need to operate in pull mode; they are not intended for general application use.
 *
 * <p>The key characteristics of these examples are that (a) the client receives the results of a query
 * or transformation as an iterator over the results, and the actual evaluation takes place
 * as the client reads items off this iterator, and (b) Saxon reads the source XML using a pull
 * parser (StAX).</p>
 */

public class PullExamples {

    private Configuration config;

    /**
     * Main program. The current directory must be the "samples" directory. Arguments:
     * <ol>
     * <li>Select examples. Each example is identified by a single letter. Use # to run all examples.
     * <li>-s Source document</li>
     * <li>-o Output file</li>
     * <li>-xsl Stylesheet</li>
     * <li>-q Query
     * </ol>
     */

    public static void main(String[] args) throws Exception {
        String examples;
        if (args.length < 1 || args[0].equals("#")) {
            examples = "abcdefghijklmnopqrstuvwxyz";
        } else {
            examples = args[0];
        }
        File input = null;
        OutputStream output = null;
        String query = null;
        File stylesheet = null;

        for (int i = 1; i < args.length; i++) {
            switch (args[i]) {
                case "-s":
                    input = new File(args[++i]);
                    break;
                case "-o":
                    output = new FileOutputStream(new File(args[++i]));
                    break;
                case "-q":
                    query = readFile(new File(args[++i]));
                    break;
                case "-xsl":
                    stylesheet = new File(args[++i]);
                    break;
                default:
                    System.err.println("Unknown argument " + args[i]);
                    break;
            }
        }

        if (input == null) {
            input = new File("data/books.xml");
        }

        if (output == null) {
            output = System.out;
        }

        if (stylesheet == null) {
            stylesheet = new File("styles/books.xsl");
        }

        if (query == null) {
            query = readFile(new File("query/books.xq"));
        }

        PullExamples app = new PullExamples();
        Configuration config = app.config = new Configuration();

        for (int i = 0; i < examples.length(); i++) {
            char ex = examples.charAt(i);
            switch (ex) {
                case 'a': {
                    System.out.println("\n\n==== Serialize the input to the output ====\n");
                    PullProvider p = app.getParser(input);
                    app.serialize(p, output);
                    break;
                }
                case 'b': {
                    System.out.println("\n\n==== Validate the input ====\n");
                    PullProvider p = app.getParser(input);
                    app.validate(p);
                    break;
                }
                case 'c': {
                    System.out.println("\n\n==== Transform the input to the output ====\n");
                    PullProvider p = app.getParser(input);
                    app.transform(p, stylesheet, output);
                    break;
                }
                case 'd': {
                    System.out.println("\n\n==== Run XQuery against the input ====\n");
                    PullProvider p = app.getParser(input);
                    app.query(p, query, output);
                    break;
                }
                case 'e': {
                    System.out.println("\n\n==== Remove PRICE elements from the input ====\n");
                    PullProvider p = app.getParser(input);
                    app.removePriceElements(p, output);
                    break;
                }
                case 'f': {
                    System.out.println("\n\n==== Compute average of PRICE elements in the input ====\n");
                    PullProvider p = app.getParser(input);
                    app.displayAveragePrice(p, output);
                    break;
                }
                case 'g': {
                    System.out.println("\n\n==== Obtain query results using a pull iterator ====\n");
                    NodeInfo node = config.buildDocumentTree(new StreamSource(input)).getRootNode();
                    PullProvider p = app.pullQueryResults(node,
                                    "declare function local:f() {" +
                                            "for $var1 in (<abc/>, <def/>)" +
                                            "return <e xmlns:x='x1'><f xmlns:y='y1' xmlns:x='x2'>xyz</f></e>};" +
                                            "local:f()"

                    );
                    app.serialize(new PullTracer(p), output);
                    break;
                }
                case 'h': {
                    System.out.println("\n\n==== Obtain query results using a pull iterator on a 'standard' tree ====\n");
                    PullProvider p1 = app.getParser(input);
                    NodeInfo node = app.buildStandardTree(p1);
                    PullProvider p2 = app.pullQueryResults(node, "//CATEGORIES");
                    app.serialize(p2, output);
                }
            }
        }
    }


    /**
     * Serialize a document that is supplied via the pull interface
     */

    public void serialize(PullProvider in, OutputStream out) throws XPathException {
        Properties props = new Properties();
        props.setProperty(OutputKeys.METHOD, "xml");
        props.setProperty(OutputKeys.INDENT, "yes");
        SerializerFactory sf = config.getSerializerFactory();
        Receiver receiver = sf.getReceiver(new StreamResult(out),
                                           new SerializationProperties(props));
        new PullPushCopier(in, receiver).copy();
    }

    /**
     * Validate a document that is supplied via the pull interface
     * (This requires the schema-aware version of Saxon)
     */

    public void validate(PullProvider in) throws XPathException {
        EnterpriseConfiguration config = new EnterpriseConfiguration();
        PipelineConfiguration pipe = in.getPipelineConfiguration();
        pipe.setConfiguration(config);
        //pipe.setSchemaURIResolver(config.getSchemaURIResolver());
        Receiver sink = new Sink(pipe);
        ParseOptions options = new ParseOptions()
                .withSchemaValidationMode(Validation.STRICT)
                .withSpaceStrippingRule(NoElementsSpaceStrippingRule.getInstance());
        Receiver validator = config.getDocumentValidator(
                sink, in.getSourceLocator().getSystemId(), options, null);
        new PullPushCopier(in, validator).copy();
        System.out.println("Done.");
    }

    /**
     * Transform a document supplied via the pull interface
     */

    public void transform(PullProvider in, File stylesheet, OutputStream out) throws TransformerException {
        TransformerFactory factory = new TransformerFactoryImpl();
        Templates templates = factory.newTemplates(new StreamSource(stylesheet));
        Transformer transformer = templates.newTransformer();
        transformer.transform(
                new PullSource(in),
                new StreamResult(out)
        );
    }

    /**
     * Run a query against input that is supplied using the pull interface
     */

    public void query(PullProvider in, String query, OutputStream out) throws XPathException {
        final StaticQueryContext sqc = config.newStaticQueryContext();
        final XQueryExpression exp = sqc.compileQuery(query);
        final DynamicQueryContext dynamicContext = new DynamicQueryContext(config);
        dynamicContext.setContextItem(config.buildDocumentTree(new PullSource(in)).getRootNode());
        Properties props = new Properties();
        props.setProperty(OutputKeys.INDENT, "yes");
        exp.run(dynamicContext, new StreamResult(out), props);
    }

    /**
     * Build a Saxon "tiny" tree from input supplied via the pull interface
     */

    public NodeInfo build(PullProvider in) throws XPathException {
        TinyBuilder builder = new TinyBuilder(in.getPipelineConfiguration());
        new PullPushCopier(in, builder).copy();
        return builder.getCurrentRoot();
    }

    /**
     * Build a Saxon "standard" tree from input supplied via the pull interface
     */

    public NodeInfo buildStandardTree(PullProvider in) throws XPathException {
        PipelineConfiguration pipe = in.getPipelineConfiguration();
        LinkedTreeBuilder builder = new LinkedTreeBuilder(pipe, Durability.MUTABLE);
        builder.open();
        new PullPushCopier(in, builder).copy();
        builder.close();
        return builder.getCurrentRoot();
    }

    /**
     * Get a PullProvider based on a StAX Parser for a given input file
     */

    public PullProvider getParser(File input) throws FileNotFoundException, XPathException {
        StaxBridge parser = new StaxBridge();
        parser.setInputStream(input.toURI().toString(), new FileInputStream(input));
        parser.setPipelineConfiguration(config.makePipelineConfiguration());
        // For diagnostics, confirm which XMLStreamReader implementation is being used
        //System.err.println("StAX parser: " + parser.getXMLStreamReader().getClass().getName());
        return parser;
    }

    /**
     * Get a PullProvider based on a document or element node in a Saxon tree
     */

    public PullProvider getTreeWalker(NodeInfo root) {
        return TreeWalker.makeTreeWalker(root);
    }

    /**
     * Run a query to produce a sequence of element nodes, and get a PullProvider over the results
     * of the query
     */

    public PullProvider pullQueryResults(NodeInfo source, String query) throws XPathException {
        final StaticQueryContext sqc = config.newStaticQueryContext();
        final XQueryExpression exp = sqc.compileQuery(query);
        final DynamicQueryContext dynamicContext = new DynamicQueryContext(config);
        dynamicContext.setContextItem(source);
        PullProvider pull = new PullFromIterator(exp.iterator(dynamicContext));
        pull = new PullNamespaceReducer(pull);
        pull.setPipelineConfiguration(config.makePipelineConfiguration());
        return pull;
    }

    /**
     * Create a copy of a document, filtered to remove all elements named "PRICE",
     * together with their contents
     */

    public void removePriceElements(PullProvider in, OutputStream out) throws XPathException {
        final NodeName priceElement = new NoNamespaceName("PRICE");
        PullFilter filter = new PullFilter(in) {
            public PullEvent next() throws XPathException {
                currentEvent = super.next();
                if (currentEvent == START_ELEMENT && getNodeName().equals(priceElement)) {
                    super.skipToMatchingEnd();
                    currentEvent = next();
                }
                return currentEvent;
            }
        };
        serialize(filter, out);
    }

    /**
     * Get the average price of books, by scanning a document and taking the average of the
     * values of the PRICE elements
     */

    public void displayAveragePrice(PullProvider in, OutputStream out) throws IOException, XPathException {
        final NodeName priceElement = new NoNamespaceName("PRICE");
        double total = 0;
        int count = 0;
        while (true) {
            PullEvent event = in.next();
            if (event == PullEvent.END_OF_INPUT) {
                break;
            }
            if (event == PullEvent.START_ELEMENT && in.getNodeName().equals(priceElement)) {
                double value = config.getConversionRules().getStringToDoubleConverter().stringToNumber(in.getStringValue().tidy());
                total += value;
                count++;
            }
        }
        double average = count == 0 ? Double.NaN : total / count;
        String result = "<result>" + average + "</result>";
        OutputStreamWriter writer = new OutputStreamWriter(out);
        writer.write(result);
        writer.flush();
    }


    /**
     * Read the contents of a file into a string
     */

    public static String readFile(File file) throws IOException {
        Reader reader = new FileReader(file);
        char[] buffer = new char[4096];
        StringBuilder sb = new StringBuilder(4096);
        while (true) {
            int n = reader.read(buffer);
            if (n > 0) {
                sb.append(buffer, 0, n);
            } else {
                break;
            }
        }
        return sb.toString();
    }


}

