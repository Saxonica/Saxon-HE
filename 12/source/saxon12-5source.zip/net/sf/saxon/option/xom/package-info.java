////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// Copyright (c) 2018-2023 Saxonica Limited
// This Source Code Form is subject to the terms of the Mozilla Public License, v. 2.0.
// If a copy of the MPL was not distributed with this file, You can obtain one at http://mozilla.org/MPL/2.0/.
// This Source Code Form is "Incompatible With Secondary Licenses", as defined by the Mozilla Public License, v. 2.0.
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
/**
 * <p>
 * This package provides glue classes that enable Saxon to process a source document supplied
 * as a XOM tree (see <a href="http://www.cafeconleche.org/XOM">http://www.cafeconleche.org/XOM</a>).</p>
 * <p>
 * The package provides implementations of the Saxon DocumentInfo and NodeInfo interfaces that act as wrappers to
 * the relevant XOM classes.</p>
 * <p>Much of the implemention of this package was done by Wolfgang Hoschek, based on Michael Kay's similar
 * package for JDOM.</p>
 */
package net.sf.saxon.option.xom;
